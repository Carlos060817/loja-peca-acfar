import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saida',
  templateUrl: './saida.component.html',
  styleUrls: ['./saida.component.css']
})
export class SaidaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  onSubmit(form: any){
    var nome_saida  = form.value.nome_saida;
    var cod_saida = form.value.cod_saida;
    var qtde_saida = form.value.qtde_saida;

    document.write("Nome:"+nome_saida+'<br>'+
    "Codigo:"+cod_saida+'<br>'+
    "Quantidade:"+qtde_saida);

    console.log(nome_saida);
    console.log(cod_saida);
    console.log(qtde_saida);
   }

}
