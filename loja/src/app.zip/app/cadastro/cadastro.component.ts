import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.component.html',
  styleUrls: ['./cadastro.component.css']
})
export class CadastroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
onSubmit(form: any){
 var nome  = form.value.nome;
 var cod = form.value.cod;
 var saida = form.value.saida;
 var entrada = form.value.entrada;
 var qtde = form.value.qtde;
 
document.write("Nome:"+nome+'<br>'+
"Codigo:"+cod+'<br>'+
"Valor de Saida:"+saida+'<br>'+
"Entrada:"+entrada+'<br>'+
"Quantidade:"+qtde);

 console.log(nome);
 console.log(cod);
 console.log(saida);
 console.log(entrada);
 console.log(qtde);
 
}
}
